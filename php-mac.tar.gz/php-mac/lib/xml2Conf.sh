#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/Users/fouber/work/php-linux/lib"
XML2_LIBS="-lxml2 -lz -lpthread  -liconv -lm "
XML2_INCLUDEDIR="-I/Users/fouber/work/php-linux/include/libxml2"
MODULE_VERSION="xml2-2.7.8"

